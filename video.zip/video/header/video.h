#include "framebf.h"

void wait_msec(unsigned int n);
void display_background();
void display_video();
void display_video2();
