void framebf_init();
void drawPixelARGB32(int x, int y, unsigned int attr);
