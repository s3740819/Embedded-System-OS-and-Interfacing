#include "../header/main.h"

void main(){
	uart_init();
	framebf_init();
	// ------------------ Run ------------------- //
	display_background();

	
	while(1) {
		display_video();
		display_video2();

	}
}

